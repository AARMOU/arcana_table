# Architecture and integration boundary

## Product rule

Argentum owns game state and game legality. The app renders the state projected for the viewing player and sends actions to the server with the originating `interactionEpoch`. It does not calculate costs, targeting legality, triggers, combat outcomes, or state-based actions.

## Data flow

```text
Compose table and card controls
    ↓ user intent and presentation
Argentum WebSocket adapter (`/game`)
    ↓ protocol messages
Argentum game server
    ↓ authoritative actions and state transitions
Argentum rules engine and built-in AI
```

The `server/argentum-engine` directory is a complete source snapshot at the revision in `ARGENTUM_REVISION`. The Android client calls a separately running server over secure WebSockets; the server source is not compiled into the APK.

## Implemented mobile flow

- Connect and reconnect using Argentum's `/game` protocol and a locally stored reconnect token.
- Start a private generated-deck game against Argentum's built-in AI.
- Render the latest full state, players, active turn, hand and battlefield. Delta updates request a fresh full state.
- Keep or mulligan, choose cards to put on the bottom, pass priority, and submit server-authored actions.
- Select a single target for actions with one target requirement.
- Customize card density, size, accent color, and active-player follow preference.

Complex multi-target and multi-step choices (modal modes, costs, attacker/blocker assignment, and other specialized prompts) are not guessed or resolved by the mobile client. Use the Argentum web client for those choices until equivalent native flows are implemented.

## Compatibility rules

- Treat the pinned server revision as the protocol contract; update the revision and verify the messages together.
- Send the server-provided action and `interactionEpoch` unchanged except for explicitly selected targets.
- Treat a state delta as a request for a full snapshot until a tested delta adapter exists.
- Keep reconnect tokens local. The player name is sent only on explicit connection.
- Do not silently choose for decisions the mobile client does not support.
