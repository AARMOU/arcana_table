## Argentum Engine

This client is designed to communicate with the Argentum Engine game server. It does not include or modify the engine source. The upstream engine is available at https://github.com/wingedsheep/argentum-engine and is distributed under the MIT License by Vincent Bons. The exact revision audited for this client is listed in `ARGENTUM_REVISION`.

Magic: The Gathering is a trademark of Wizards of the Coast LLC. Argentum is an unofficial project and is not affiliated with, endorsed by, or sponsored by Wizards of the Coast.
