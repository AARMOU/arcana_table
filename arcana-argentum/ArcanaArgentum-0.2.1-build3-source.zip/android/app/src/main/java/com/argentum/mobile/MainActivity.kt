package com.arcanaargentum.mobile

import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL

private val Ink = Color(0xFF101615)
private val Panel = Color(0xFF192220)
private val PanelRaised = Color(0xFF26332F)
private val Gold = Color(0xFFFFD166)
private val TextMain = Color(0xFFEAF1ED)
private val TextMuted = Color(0xFFA4B1AB)
private val Green = Color(0xFF89E3B0)
private val Accents = listOf(Color(0xFF89E3B0), Color(0xFFFFD166), Color(0xFF80B8FF), Color(0xFFE38DB3), Color(0xFFC5A3FF))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("arcana_argentum", MODE_PRIVATE)
        setContent {
            ArcanaArgentumTheme {
                ArcanaArgentumApp(
                    initialServer = prefs.getString("server_url", "") ?: "",
                    initialName = prefs.getString("player_name", "Player") ?: "Player",
                    initialAccent = prefs.getInt("accent", 0),
                    initialCompact = prefs.getBoolean("compact_cards", false),
                    initialScale = prefs.getInt("card_scale", 1),
                    initialFollow = prefs.getBoolean("follow_turn", true),
                    onSaveSettings = { server, name -> prefs.edit().putString("server_url", server).putString("player_name", name).apply() },
                    onSaveStyle = { accent, compact, scale, follow -> prefs.edit().putInt("accent", accent).putBoolean("compact_cards", compact).putInt("card_scale", scale).putBoolean("follow_turn", follow).apply() },
                )
            }
        }
    }
}

@Composable
private fun ArcanaArgentumTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Green, onPrimary = Ink, background = Ink, surface = Panel, onSurface = TextMain, secondary = Gold), content = content)
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
private fun ArcanaArgentumApp(
    initialServer: String, initialName: String, initialAccent: Int, initialCompact: Boolean, initialScale: Int, initialFollow: Boolean,
    onSaveSettings: (String, String) -> Unit, onSaveStyle: (Int, Boolean, Int, Boolean) -> Unit,
) {
    val context = LocalContext.current
    var server by remember { mutableStateOf(initialServer) }
    var name by remember { mutableStateOf(initialName) }
    var status by remember { mutableStateOf("Disconnected") }
    var notice by remember { mutableStateOf("") }
    var inGame by remember { mutableStateOf(false) }
    var gameState by remember { mutableStateOf<JSONObject?>(null) }
    var interactionEpoch by remember { mutableStateOf("") }
    var legalActions by remember { mutableStateOf(emptyList<JSONObject>()) }
    var mulliganPrompt by remember { mutableStateOf<JSONObject?>(null) }
    var bottomPrompt by remember { mutableStateOf<JSONObject?>(null) }
    var selectedBottomIds by remember { mutableStateOf(setOf<String>()) }
    var targetAction by remember { mutableStateOf<JSONObject?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var showStyle by remember { mutableStateOf(false) }
    var accentIndex by remember { mutableIntStateOf(initialAccent.coerceIn(0, Accents.lastIndex)) }
    var compactCards by remember { mutableStateOf(initialCompact) }
    var cardScale by remember { mutableIntStateOf(initialScale.coerceIn(0, 2)) }
    var followTurn by remember { mutableStateOf(initialFollow) }
    val accent = Accents[accentIndex]
    val socketRef = remember { SocketRef() }
    val practiceSubmitted = remember { mutableStateOf(false) }
    val socket = remember {
        ArgentumSocket(context) { message ->
            when (message.optString("type")) {
                "quickGameLobbyState" -> if (!practiceSubmitted.value) {
                    socketRef.value?.send(JSONObject().put("type", "submitQuickGameLobbyDeck").put("deckList", JSONObject()))
                    socketRef.value?.send(JSONObject().put("type", "setQuickGameLobbyReady").put("ready", true))
                    practiceSubmitted.value = true
                }
                "stateUpdate" -> {
                    gameState = message.optJSONObject("state")
                    legalActions = jsonObjects(message.optJSONArray("legalActions"))
                    interactionEpoch = message.optString("interactionEpoch")
                    inGame = true
                    targetAction = null
                }
                "stateDeltaUpdate" -> socketRef.value?.send(JSONObject().put("type", "requestResync"))
                "mulliganDecision" -> mulliganPrompt = message
                "chooseBottomCards" -> { bottomPrompt = message; selectedBottomIds = emptySet() }
                "mulliganComplete" -> { mulliganPrompt = null; bottomPrompt = null }
                "gameStarted" -> { inGame = true; notice = "Game started. Argentum is handling the rules." }
                "gameOver" -> notice = "Game finished."
                "error" -> notice = message.optString("message", "The server returned an error.")
            }
        }
    }
    SideEffect { socketRef.value = socket }
    DisposableEffect(socket) { socket.onStatus = { status = it }; onDispose { socket.disconnect() } }

    Scaffold(
        containerColor = Ink,
        topBar = {
            TopAppBar(
                title = { Column(verticalArrangement = Arrangement.spacedBy(2.dp)) { Text("ARCANA TABLE", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = TextMain, letterSpacing = 1.1.sp); Text("ARGENTUM RULES · EXPERIMENTAL", style = MaterialTheme.typography.labelSmall, color = TextMuted) } },
                actions = {
                    if (inGame) IconButton(onClick = { showStyle = true }) { Icon(Icons.Default.Palette, contentDescription = "Table style", tint = accent) }
                    StatusPill(status)
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, contentDescription = "Settings", tint = TextMain) }
                }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink),
            )
        },
    ) { insets ->
        when {
            showSettings -> SettingsDialog(server, name, status, { server = it }, { name = it }, { showSettings = false }, { onSaveSettings(server, name); showSettings = false }, {
                onSaveSettings(server, name)
                runCatching { socket.connect(server, name) }.onFailure { notice = it.message ?: "Could not connect." }
            }, { socket.disconnect() }, Modifier.padding(insets))
            showStyle -> StyleDialog(accentIndex, compactCards, cardScale, followTurn, { accentIndex = it }, { compactCards = it }, { cardScale = it }, { followTurn = it }, {
                onSaveStyle(accentIndex, compactCards, cardScale, followTurn); showStyle = false
            }, { showStyle = false })
            inGame && gameState != null -> GameScreen(
                state = gameState!!, actions = legalActions, epoch = interactionEpoch, accent = accent,
                compactCards = compactCards, cardScale = cardScale, followTurn = followTurn,
                mulliganPrompt = mulliganPrompt, bottomPrompt = bottomPrompt, selectedBottomIds = selectedBottomIds,
                targetAction = targetAction,
                onSelectBottom = { id -> selectedBottomIds = if (id in selectedBottomIds) selectedBottomIds - id else selectedBottomIds + id },
                onTargetAction = { legal ->
                    val requirements = legal.optJSONArray("targetRequirements")
                    val oneTargetOnly = legal.optInt("targetCount", 1) <= 1 && legal.optInt("minTargets", 1) <= 1 &&
                        (requirements == null || requirements.length() <= 1) &&
                        (requirements?.optJSONObject(0)?.optInt("maxTargets", 1) ?: 1) <= 1
                    if (oneTargetOnly) targetAction = legal
                    else notice = "This play needs a multi-part choice. Continue this game in Argentum’s web client for that decision."
                }, onCancelTarget = { targetAction = null },
                onSubmitTarget = { action, target ->
                    val base = action.optJSONObject("action") ?: JSONObject()
                    val targets = JSONArray().put(target)
                    base.put("targets", targets)
                    sendAction(socket, base, interactionEpoch)
                    targetAction = null
                },
                notice = notice,
                onPass = { legalActions.firstOrNull { it.optString("actionType") == "PassPriority" }?.optJSONObject("action")?.let { sendAction(socket, it, interactionEpoch) } },
                onKeep = { socket.send(JSONObject().put("type", "keepHand")) },
                onMulligan = { socket.send(JSONObject().put("type", "mulligan")) },
                onSubmitBottom = { val ids = JSONArray(); selectedBottomIds.forEach(ids::put); socket.send(JSONObject().put("type", "chooseBottomCards").put("cardIds", ids)); bottomPrompt = null },
                onAction = { action -> sendAction(socket, action, interactionEpoch) }, modifier = Modifier.padding(insets),
            )
            else -> HomeScreen(status, notice, server.isNotBlank(), { showSettings = true }, {
                if (status != "Connected") notice = "Connect to an Argentum server in Settings first."
                else {
                    practiceSubmitted.value = false; inGame = false; gameState = null; notice = "Creating a generated-deck practice game…"
                    socket.send(JSONObject().put("type", "createQuickGameLobby").put("vsAi", true))
                }
            }, Modifier.padding(insets))
        }
    }
}

private class SocketRef { var value: ArgentumSocket? = null }
private fun sendAction(socket: ArgentumSocket, action: JSONObject, epoch: String) {
    val packet = JSONObject().put("type", "submitAction").put("action", action)
    epoch.takeIf(String::isNotBlank)?.let { packet.put("interactionEpoch", it) }
    socket.send(packet)
}

@Composable
private fun HomeScreen(status: String, notice: String, serverConfigured: Boolean, onSettings: () -> Unit, onStart: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize()) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("VERSION 0.2.1 · ARGENTUM SDK · BUILD 3", color = TextMuted, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                StatusPill(status)
            }
            Text("•  READY TO PLAY", color = Green, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            Column(Modifier.fillMaxWidth().border(2.dp, Green.copy(alpha = .72f), RoundedCornerShape(22.dp)).background(Panel, RoundedCornerShape(20.dp)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("ARGENTUM · ROOM AUTHORITY", color = Green, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black, letterSpacing = .6.sp)
                Text("Your table, with Argentum deciding the game.", color = TextMain, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Arcana’s table layout and card presentation stay on this phone. Argentum supplies legal actions and authoritative game state.", color = TextMuted, style = MaterialTheme.typography.bodyMedium)
                HorizontalDivider(color = TextMuted.copy(alpha = .22f))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column { Text("PRACTICE TABLE", color = Gold, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black); Text("You + Argentum AI", color = TextMuted, style = MaterialTheme.typography.bodySmall) }
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Gold, modifier = Modifier.size(26.dp))
                }
                Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(54.dp), enabled = status == "Connected", colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Ink), shape = RoundedCornerShape(14.dp)) {
                    Text(if (status == "Connected") "START PRACTICE GAME" else "CONNECT TO ARGENTUM", fontWeight = FontWeight.Black)
                }
                if (!serverConfigured || status != "Connected") OutlinedButton(onClick = onSettings, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("SERVER SETTINGS", color = Green, fontWeight = FontWeight.Bold) }
            }
            if (notice.isNotBlank()) Text(notice, color = Gold, style = MaterialTheme.typography.bodyMedium)
        }
        Text("Arcana Table UI  ·  Argentum rules", color = TextMuted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp))
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
private fun GameScreen(
    state: JSONObject, actions: List<JSONObject>, epoch: String, accent: Color, compactCards: Boolean, cardScale: Int, followTurn: Boolean,
    mulliganPrompt: JSONObject?, bottomPrompt: JSONObject?, selectedBottomIds: Set<String>, targetAction: JSONObject?,
    onSelectBottom: (String) -> Unit, onTargetAction: (JSONObject) -> Unit, onCancelTarget: () -> Unit, onSubmitTarget: (JSONObject, JSONObject) -> Unit,
    notice: String, onPass: () -> Unit, onKeep: () -> Unit, onMulligan: () -> Unit, onSubmitBottom: () -> Unit, onAction: (JSONObject) -> Unit, modifier: Modifier = Modifier,
) {
    val players = jsonObjects(state.optJSONArray("players"))
    val cards = state.optJSONObject("cards") ?: JSONObject()
    val zones = jsonObjects(state.optJSONArray("zones"))
    val viewing = state.optString("viewingPlayerId")
    val activeId = state.optString("activePlayerId")
    val priorityId = state.optString("priorityPlayerId")
    val selectedTargetAction = targetAction
    val targetIds = selectedTargetAction?.optJSONArray("validTargets")
        ?: selectedTargetAction?.optJSONArray("targetRequirements")?.optJSONObject(0)?.optJSONArray("validTargets")
    var pendingTarget by remember(selectedTargetAction) { mutableStateOf<JSONObject?>(null) }
    var showHand by remember { mutableStateOf(false) }
    var showActions by remember { mutableStateOf(false) }
    val scaleFactor = listOf(.84f, 1f, 1.18f)[cardScale.coerceIn(0, 2)]
    fun cardsInZone(ownerId: String, zoneType: String): List<JSONObject> = zones
        .filter { z -> z.optJSONObject("zoneId")?.optString("ownerId") == ownerId && z.optJSONObject("zoneId")?.optString("zoneType") == zoneType }
        .flatMap { z -> val ids = z.optJSONArray("cardIds") ?: JSONArray(); (0 until ids.length()).mapNotNull { cards.optJSONObject(ids.optString(it)) } }
    val viewerHand = cardsInZone(viewing, "HAND")
    val displayPlayers = if (followTurn) players.sortedByDescending { it.optString("playerId") == activeId } else players

    Column(modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("GAME IN PROGRESS · ROUND ${state.optInt("roundNumber", state.optInt("turnNumber", 1))}", color = TextMuted, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Text("${state.optString("currentPhase", "STARTING").replace('_', ' ')} · ${state.optString("currentStep", "").replace('_', ' ')}", color = TextMuted, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }
            item { Text("•  GAME IN PROGRESS", color = Green, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black, letterSpacing = .8.sp) }
            item {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    players.forEach { player ->
                        val id = player.optString("playerId")
                        val commander = cardsInZone(id, "COMMAND").firstOrNull()
                            ?: cards.keys().asSequence().mapNotNull(cards::optJSONObject).firstOrNull { it.optBoolean("isCommander") && it.optString("ownerId") == id }
                        Card(colors = CardDefaults.cardColors(containerColor = if (id == activeId) PanelRaised else Panel), shape = RoundedCornerShape(15.dp), border = androidx.compose.foundation.BorderStroke(if (id == activeId) 2.dp else 1.dp, if (id == activeId) Green else TextMuted.copy(alpha = .2f)), modifier = Modifier.width(150.dp)) {
                            Row(Modifier.padding(9.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                if (commander != null) ArcanaCard(commander, accent, true, .8f, Modifier.width(44.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(if (id == viewing) "YOU" else player.optString("name", "PLAYER").uppercase(), color = TextMain, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black, maxLines = 1)
                                    Text("${player.optInt("life", 40)} LIFE", color = Green, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
            item { Text("ARGENTUM · ROOM AUTHORITY", color = Green, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black, letterSpacing = .4.sp) }
            item { Text("FULL TABLE · ${players.size}/4 PLAYERS", color = TextMuted, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
            items(displayPlayers, key = { it.optString("playerId") }) { player ->
                val id = player.optString("playerId")
                val isActive = id == activeId
                val ownCommander = cardsInZone(id, "COMMAND").firstOrNull()
                    ?: cards.keys().asSequence().mapNotNull(cards::optJSONObject).firstOrNull { it.optBoolean("isCommander") && it.optString("ownerId") == id }
                val permanents = cards.keys().asSequence().mapNotNull(cards::optJSONObject)
                    .filter { it.optJSONObject("zone")?.optString("zoneType") == "BATTLEFIELD" && it.optString("controllerId") == id }
                    .toList()
                val handCount = player.optInt("handSize")
                val libraryCount = player.optInt("librarySize")
                Column(Modifier.fillMaxWidth().border(if (isActive) 2.dp else 1.dp, if (isActive) Green else TextMuted.copy(alpha = .25f), RoundedCornerShape(20.dp)).background(Panel.copy(alpha = .35f), RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("${if (isActive) "● " else ""}${if (id == viewing) "YOU" else player.optString("name", "PLAYER").uppercase()} · ${if (isActive) "TURN" else "WAITING"}", color = if (isActive) Green else TextMain, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Black)
                            Text("$handCount in hand  ·  $libraryCount in library", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                        }
                        Text(player.optInt("life", 40).toString(), color = Green, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
                    }
                    if (ownCommander != null) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            ArcanaCard(ownCommander, accent, false, .82f, Modifier.width(112.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) { Text("COMMANDER", color = Gold, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black); Text(ownCommander.optString("name"), color = Gold, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, maxLines = 2) }
                        }
                    }
                    Text("${state.optString("currentPhase", "TURN").replace('_', ' ')} · ${state.optString("currentStep", "").replace('_', ' ')}", color = TextMuted, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    HorizontalDivider(color = TextMuted.copy(alpha = .14f))
                    Text("BOARD · ${permanents.size} PERMANENTS", color = TextMuted, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black)
                    if (permanents.isEmpty()) Text("No permanents", color = TextMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp))
                    else Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        permanents.forEach { card ->
                            val cardId = card.optString("id")
                            val cardActions = actions.filter { legal -> val action = legal.optJSONObject("action") ?: JSONObject(); action.optString("cardId") == cardId || action.optString("permanentId") == cardId || action.optString("sourceId") == cardId }
                            ArcanaCard(card, accent, compactCards, scaleFactor, Modifier.width((116 * scaleFactor).dp), footer = {
                                cardActions.take(2).forEach { legal -> TextButton(onClick = { if (legal.optBoolean("requiresTargets")) onTargetAction(legal) else onAction(legal.optJSONObject("action") ?: JSONObject()) }, contentPadding = PaddingValues(2.dp)) { Text(legal.optString("description", legal.optString("actionType")), color = accent, maxLines = 2, style = MaterialTheme.typography.labelSmall) } }
                            })
                        }
                    }
                }
            }
            if (mulliganPrompt != null) item { Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Green.copy(alpha = .55f))) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("OPENING HAND", color = Green, fontWeight = FontWeight.Black); Text("Keep this hand or ask Argentum to deal a new one.", color = TextMuted); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = onKeep, colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Ink)) { Text("KEEP HAND") }; OutlinedButton(onClick = onMulligan) { Text("MULLIGAN", color = TextMain) } } } } }
            if (bottomPrompt != null) {
                val needed = bottomPrompt.optInt("cardsToPutOnBottom"); val hand = bottomPrompt.optJSONArray("hand") ?: JSONArray()
                item { Text("CHOOSE $needed CARD(S) TO PUT ON BOTTOM", color = Green, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black) }
                items((0 until hand.length()).map(hand::optString)) { id ->
                    val info = bottomPrompt.optJSONObject("cards")?.optJSONObject(id); val label = info?.optString("name")?.takeIf(String::isNotBlank) ?: cards.optJSONObject(id)?.optString("name") ?: "Card"
                    FilterChip(selected = id in selectedBottomIds, onClick = { if (id in selectedBottomIds || selectedBottomIds.size < needed) onSelectBottom(id) }, label = { Text(label) })
                }
                item { Button(onClick = onSubmitBottom, enabled = selectedBottomIds.size == needed, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Ink)) { Text("CONFIRM BOTTOM CARDS") } }
            }
            if (notice.isNotBlank()) item { Text(notice, color = Gold, style = MaterialTheme.typography.bodySmall) }
        }
        Row(Modifier.fillMaxWidth().background(Ink).navigationBarsPadding().padding(horizontal = 14.dp, vertical = 9.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onPass, enabled = actions.any { it.optString("actionType") == "PassPriority" }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Text("PASS PRIORITY", color = Green, maxLines = 1, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black) }
            Button(onClick = { showHand = true }, modifier = Modifier.weight(1.1f), colors = ButtonDefaults.buttonColors(containerColor = PanelRaised, contentColor = Green), shape = RoundedCornerShape(12.dp)) { Text("HAND  ${viewerHand.size}", maxLines = 1, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black) }
            Button(onClick = { showActions = true }, modifier = Modifier.weight(1f), enabled = actions.isNotEmpty(), colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Ink), shape = RoundedCornerShape(12.dp)) { Text("ACTIONS", maxLines = 1, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black) }
        }
    }

    if (showHand) ModalBottomSheet(onDismissRequest = { showHand = false }, containerColor = Panel) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("YOUR HAND · ${viewerHand.size}", color = Green, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Black)
            if (viewerHand.isEmpty()) Text("Your hand is empty.", color = TextMuted, modifier = Modifier.padding(bottom = 24.dp))
            else Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 24.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                viewerHand.forEach { card ->
                    val cardId = card.optString("id")
                    val cardActions = actions.filter { legal -> val action = legal.optJSONObject("action") ?: JSONObject(); action.optString("cardId") == cardId || action.optString("sourceId") == cardId }
                    ArcanaCard(card, accent, compactCards, scaleFactor, Modifier.width((150 * scaleFactor).dp), footer = {
                        cardActions.take(4).forEach { legal -> TextButton(onClick = { showHand = false; if (legal.optBoolean("requiresTargets")) onTargetAction(legal) else onAction(legal.optJSONObject("action") ?: JSONObject()) }, enabled = legal.optBoolean("isAffordable", true), contentPadding = PaddingValues(2.dp)) { Text(legal.optString("description", legal.optString("actionType")), color = if (legal.optBoolean("isAffordable", true)) Green else TextMuted, maxLines = 2, style = MaterialTheme.typography.labelSmall) }
                    })
                }
            }
        }
    }
    if (showActions) AlertDialog(onDismissRequest = { showActions = false }, containerColor = Panel, title = { Text("ARGENTUM ACTIONS", color = Green, fontWeight = FontWeight.Black) }, text = {
        Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (actions.isEmpty()) Text("No actions are available right now.", color = TextMuted)
            actions.forEach { legal ->
                val description = legal.optString("description", legal.optString("actionType"))
                OutlinedButton(onClick = { showActions = false; if (legal.optBoolean("requiresTargets")) onTargetAction(legal) else onAction(legal.optJSONObject("action") ?: JSONObject()) }, enabled = legal.optBoolean("isAffordable", true), modifier = Modifier.fillMaxWidth()) { Text(description, color = TextMain, maxLines = 2) }
            }
        }
    }, confirmButton = { TextButton(onClick = { showActions = false }) { Text("CLOSE", color = Green) } })

    if (selectedTargetAction != null) AlertDialog(
        onDismissRequest = onCancelTarget, containerColor = Panel,
        title = { Text(selectedTargetAction.optString("targetDescription", "Choose a target"), color = TextMain) },
        text = {
            val ids = targetIds ?: JSONArray()
            Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (ids.length() == 0) Text("No target list was supplied for this action.", color = TextMuted)
                for (i in 0 until ids.length()) {
                    val id = ids.optString(i)
                    val player = players.firstOrNull { it.optString("playerId") == id }
                    val card = cards.optJSONObject(id)
                    val label = player?.let { "${it.optString("name")} · player" } ?: card?.let { "${it.optString("name")} · ${it.optString("typeLine")}" } ?: "Target $id"
                    val chosen = when {
                        player != null -> JSONObject().put("type", "Player").put("playerId", id)
                        card != null && card.optJSONObject("zone")?.optString("zoneType") == "Battlefield" -> JSONObject().put("type", "Permanent").put("entityId", id)
                        card != null && card.optJSONObject("zone")?.optString("zoneType") == "Stack" -> JSONObject().put("type", "Spell").put("spellEntityId", id)
                        card != null -> {
                            val zone = card.optJSONObject("zone")
                            val zoneType = zone?.optString("zoneType").orEmpty()
                            if (zoneType !in setOf("Graveyard", "Exile", "Hand", "Library", "Command", "Sideboard")) continue
                            JSONObject().put("type", "Card").put("cardId", id).put("ownerId", card.optString("ownerId")).put("zone", zoneType)
                        }
                        else -> continue
                    }
                    OutlinedButton(onClick = { pendingTarget = chosen }, modifier = Modifier.fillMaxWidth()) { Text(label, color = if (pendingTarget?.toString() == chosen.toString()) accent else TextMain) }
                }
            }
        },
        confirmButton = { TextButton(onClick = { pendingTarget?.let { onSubmitTarget(selectedTargetAction, it) } }, enabled = pendingTarget != null) { Text("Confirm target", color = accent) } },
        dismissButton = { TextButton(onClick = onCancelTarget) { Text("Cancel") } },
    )
}

@Composable
private fun ArcanaCard(card: JSONObject, accent: Color, compact: Boolean, scale: Float, modifier: Modifier = Modifier, footer: @Composable ColumnScope.() -> Unit = {}) {
    val title = card.optString("name", "Card")
    val art = card.optString("imageUri").takeIf { it.startsWith("https://") || it.startsWith("http://") }
    var bitmap by remember(art) { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    LaunchedEffect(art) {
        bitmap = art?.let { uri -> withContext(Dispatchers.IO) { runCatching { URL(uri).openConnection().apply { connectTimeout = 5000; readTimeout = 7000 }.getInputStream().use { BitmapFactory.decodeStream(it)?.asImageBitmap() } }.getOrNull() } }
    }
    Card(modifier, colors = CardDefaults.cardColors(containerColor = PanelRaised), shape = RoundedCornerShape(15.dp), border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = .38f))) {
        Column {
            if (!compact) {
                if (bitmap != null) Image(bitmap!!, contentDescription = title, modifier = Modifier.fillMaxWidth().height((116 * scale).dp).clip(RoundedCornerShape(topStart = 15.dp, topEnd = 15.dp)), contentScale = ContentScale.Crop)
                else Box(Modifier.fillMaxWidth().height((82 * scale).dp).background(accent.copy(alpha = .12f)), contentAlignment = Alignment.Center) { Icon(Icons.Default.AutoAwesome, null, tint = accent.copy(alpha = .7f), modifier = Modifier.size(30.dp)) }
            }
            Column(Modifier.padding(if (compact) 9.dp else 10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(title, color = TextMain, fontWeight = FontWeight.Bold, maxLines = 2, style = MaterialTheme.typography.labelLarge)
                Text(card.optString("manaCost").ifBlank { card.optString("typeLine") }, color = accent, maxLines = 1, style = MaterialTheme.typography.labelSmall)
                if (!compact) {
                    Text(card.optString("typeLine"), color = TextMuted, maxLines = 2, style = MaterialTheme.typography.labelSmall)
                    card.optString("power").takeIf(String::isNotBlank)?.let { Text("$it/${card.optString("toughness")}", color = TextMain, fontWeight = FontWeight.Bold) }
                }
                footer()
            }
        }
    }
}

@Composable
private fun StyleDialog(accent: Int, compact: Boolean, scale: Int, follow: Boolean, onAccent: (Int) -> Unit, onCompact: (Boolean) -> Unit, onScale: (Int) -> Unit, onFollow: (Boolean) -> Unit, onSave: () -> Unit, onClose: () -> Unit) {
    AlertDialog(onDismissRequest = onClose, containerColor = Panel, title = { Text("Customize your table", color = TextMain) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Text("Accent", color = TextMuted)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { Accents.forEachIndexed { index, color -> Surface(onClick = { onAccent(index) }, color = color, shape = RoundedCornerShape(50), modifier = Modifier.size(30.dp), border = if (accent == index) androidx.compose.foundation.BorderStroke(3.dp, Color.White) else null) {} } }
            Text("Card size", color = TextMuted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Small", "Regular", "Large").forEachIndexed { index, label -> FilterChip(selected = scale == index, onClick = { onScale(index) }, label = { Text(label) }) } }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) { Text("Compact card faces", color = TextMain); Switch(compact, onCompact) }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) { Text("Auto-follow active player", color = TextMain); Switch(follow, onFollow) }
        }
    }, confirmButton = { TextButton(onClick = onSave) { Text("Save", color = Gold) } }, dismissButton = { TextButton(onClick = onClose) { Text("Close") } })
}

@Composable
private fun SectionLabel(text: String, accent: Color) { Text(text, color = accent, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black) }

@Composable
private fun StatusPill(status: String) {
    val connected = status == "Connected"
    Surface(color = if (connected) Color(0xFF17382C) else PanelRaised, shape = RoundedCornerShape(50)) { Row(Modifier.padding(horizontal = 9.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) { Box(Modifier.size(7.dp).background(if (connected) Green else TextMuted, RoundedCornerShape(50))); Text(status.take(18), color = if (connected) Green else TextMuted, style = MaterialTheme.typography.labelSmall) } }
}

@Composable
private fun SettingsDialog(server: String, name: String, status: String, onServer: (String) -> Unit, onName: (String) -> Unit, onClose: () -> Unit, onSave: () -> Unit, onConnect: () -> Unit, onDisconnect: () -> Unit, modifier: Modifier = Modifier) {
    AlertDialog(onDismissRequest = onClose, containerColor = Panel, title = { Text("Connect to Argentum", color = TextMain) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Connect to an Argentum game server. Your player name is sent when you connect.", color = TextMuted)
            OutlinedTextField(server, onServer, label = { Text("Secure server address") }, placeholder = { Text("https://your-argentum-server") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
            OutlinedTextField(name, onName, label = { Text("Player name") }, singleLine = true)
            Text("Status: $status", color = if (status == "Connected") Green else TextMuted)
        }
    }, confirmButton = { Row { TextButton(onClick = onSave) { Text("Save") }; if (status == "Connected") TextButton(onClick = onDisconnect) { Text("Disconnect") } else TextButton(onClick = onConnect) { Text("Connect", color = Gold) } } }, dismissButton = { TextButton(onClick = onClose) { Text("Close") } })
}

private fun jsonObjects(array: JSONArray?): List<JSONObject> = buildList { if (array != null) for (index in 0 until array.length()) array.optJSONObject(index)?.let(::add) }
