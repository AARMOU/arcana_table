package com.arcanaargentum.mobile

import android.content.Context
import android.os.Handler
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Thin transport adapter. It sends player intent and renders server responses; it owns no rules. */
class ArgentumSocket(context: Context, private val onMessage: (JSONObject) -> Unit) {
    private val prefs = context.getSharedPreferences("argentum", Context.MODE_PRIVATE)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .pingInterval(25, TimeUnit.SECONDS)
        .build()
    private var socket: WebSocket? = null

    @Volatile var status: String = "Disconnected"
        private set
    var onStatus: ((String) -> Unit)? = null

    fun connect(serverUrl: String, playerName: String) {
        disconnect()
        val endpoint = websocketEndpoint(serverUrl)
        status = "Connecting"
        emitStatus(status)
        val request = Request.Builder().url(endpoint).build()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                status = "Authenticating"
                emitStatus(status)
                val message = JSONObject()
                    .put("type", "connect")
                    .put("playerName", playerName.trim().ifEmpty { "Player" })
                prefs.getString("reconnect_token", null)?.let { message.put("token", it) }
                webSocket.send(message.toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val message = runCatching { JSONObject(text) }.getOrNull() ?: return
                when (message.optString("type")) {
                    "connected", "reconnected" -> {
                        message.optString("token").takeIf { it.isNotBlank() }?.let {
                            prefs.edit().putString("reconnect_token", it).apply()
                        }
                        status = "Connected"
                        emitStatus(status)
                    }
                }
                mainHandler.post { onMessage(message) }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                status = t.message?.let { "Connection failed: $it" } ?: "Connection failed"
                emitStatus(status)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                status = "Disconnected"
                emitStatus(status)
            }
        })
    }

    fun send(message: JSONObject) {
        socket?.send(message.toString())
    }

    fun disconnect() {
        socket?.close(1000, "User disconnected")
        socket = null
        status = "Disconnected"
        emitStatus(status)
    }

    private fun websocketEndpoint(value: String): String {
        val base = value.trim().trimEnd('/')
        require(base.startsWith("https://")) {
            "Enter a server address beginning with https://"
        }
        return "wss://" + base.substringAfter("://") + "/game"
    }

    private fun emitStatus(value: String) {
        mainHandler.post { onStatus?.invoke(value) }
    }
}
