# Arcana · Argentum Android app

Standalone Android client combining Arcana-style card-table presentation with Argentum's server-authoritative rules and game state.

## Build

Requires JDK 17 or 21, Android SDK Platform 36, and Android Build Tools 35.0.0 or newer.

```sh
./gradlew assembleDebug
```

The APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

## Connect

In app Settings, enter an HTTPS Argentum server URL and a player name. The client connects to `wss://<host>/game`. The included `../server/argentum-engine` tree is the full pinned source snapshot, not a server process embedded in the Android APK.

## Display and actions

The table follows the active player when that preference is enabled, highlights the active seat, and can show image-backed or compact text cards at three sizes with a selectable accent. Preferences are stored on-device. The client uses server state and legal-action payloads; it does not implement game rules.

One-target actions and common play/priority flows are surfaced. Complex decisions that require multiple picks or dedicated decision UI are not auto-resolved; use Argentum's web client for those until corresponding mobile screens are added. State deltas trigger a full resync request.
